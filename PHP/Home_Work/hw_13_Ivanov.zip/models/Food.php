<?php
class Food extends Item
{
    protected $price;

    public static function getType()
    {
        return 'food';
    }

    public function getSummaryLine()
    {
        return 'title: ' . $this->getTitle() . ' type: ' . self::getType() . ' price: ' . $this->getPrice();
    }

    public function getPrice()
    {
        return $this->price - 10;
    }
}
