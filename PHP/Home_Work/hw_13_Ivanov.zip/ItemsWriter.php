<?php
/**
 * Created by PhpStorm.
 * User: anton
 * Date: 24.03.19
 * Time: 9:14
 */

class ItemsWriter
{
    /**
     * @var Writable[] $items
     */
    public $itemsList;

    public function addItem(Writable $object)
    {
        $this->itemsList[] = $object;
    }

    public function wrinte()
    {
        foreach($this->itemsList as $item){
            $item->getSummaryLine();
        }
    }

}
