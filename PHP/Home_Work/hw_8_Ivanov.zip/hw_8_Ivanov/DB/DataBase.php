<?php
/**
 * @var $tovars массив с для магазина
*/
$tovars = [
    458=>[
        'title' => 'Чехол для iPhone 6',
        'price_val' => 450,
    ],
    456=>[
        'title' => 'Аккамулятор iPhone 6',
        'price_val' => 10,
    ],
    258=>[
        'title' => 'Защитное стекло',
        'price_val' => 200,
    ],
    244=>[
        'title' => 'Защитное стекло led',
        'price_val' => 400,
    ],
    741=>[
        'title' => 'Apple AirPors',
        'price_val' => 300,
    ],
    445=>[
        'title' => 'Наушники',
        'price_val' => 46,
    ],
    142=>[
        'title' => 'Power Bank Air',
        'price_val' => 800,
    ],
    112=>[
        'title' => 'Зарядка type c',
        'price_val' => 50,
    ],
    112=>[
        'title' => 'Блочек Samsung',
        'price_val' => 20,
    ],
    331=>[
        'title' => 'Брелок для телефона NOKIA',
        'price_val' => 50,
    ],

];