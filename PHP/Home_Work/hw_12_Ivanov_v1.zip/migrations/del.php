<?php
require_once '../classes/Application.php';
require_once '../classes/Message.php';
$db = Application::connectionDB();
try {
    $db->exec('drop table `publications`');
    show('Del success!');
} catch(PDOException $e) {
    show('Error in delet');
}