<?php require_once 'Controller.php'; ?>
<!doctype html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>InfoCar</title>
</head>
<body style="background-image: url('img/bg.jpg'); background-position: 50% 65px">
    <div class="navbar navbar-expand bg-dark navbar-dark mb-5">
        <div class="container">
            <a class="navbar-brand " href="index.php">
                <span class="badge badge-info">InfoCar.ua™</span>
            </a>
            <div class="navbar navbar-collapse">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a href="index.php" class="nav-link">Главная</a>
                    </li>
                    <?php if(true): ?>
                    <li class="nav-item">
                        <a href="index.php?category=news" class="nav-link">Новости</a>
                    </li>
                    <li class="nav-item">
                        <a href="index.php?category=article" class="nav-link">Статьи</a>
                    </li>
                    <?php endif; ?>
                </ul>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="content">
            <?php
            /**
             * @var Publication[] $publications;
             */
            //var_dump($publications[0]->getText());
            ?>
            <?php if(isset($publications) && (count($publications) > 0) && $publications[0] instanceof Publication): ?>
            <?php foreach ($publications as $publication): ?>
            <div class="card my-3">
                <div class="card-body">
                    <div class="card-title">
                        <h4><?= $publication->getTitle() ?></h4>
                    </div>
                    <div class="card-subtitle">
                        <span class="badge <?= ($publication->getType() == 'news') ? 'badge-info' : 'badge-warning' ?>">
                            <?= $publication->type ?>
                        </span>
                        <span class="ml-2 alert-light">
                            <?= ($publication->getType() == 'news')? 'Источник: ':'Автор: ' ?>
                            <?= $publication->getSuperProperty() ?>
                        </span>
                    </div>
                    <?php //if not parameter ID then print a short description ?>
                    <?php if (!isset($_GET['id'])): ?>
                    <p class="card-text mt-4 text-justify"><?= $publication->getDescription() ?></p>
                    <a href="index.php?id=<?= $publication->getId() ?>" class="card-link">Подробее</a>
                    <?php else: ?>
                    <p class="card-text mt-4 text-justify"><?= $publication->getText() ?></p>
                    <?php endif; ?>
                </div>
            </div>
            <?php endforeach; ?>
            <?php else: ?>
            <div>
                <p class="alert alert-warning">Нет ни одной записи, обратитесь в администратору вашего предприятия.</p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</body>
</html>
