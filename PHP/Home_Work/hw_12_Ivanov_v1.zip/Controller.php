<?php
    require_once 'classes/PublicationViewer.php';
    require_once 'classes/PublisherFactory.php';

    /**
     * @var Publication[] $publications array contains all publications from dataBase
     */
    $publications;
    // The choice of one object
    if (isset($_GET['id']) && is_numeric($_GET['id'])){
        $id = $_GET['id'];
        $publications[] = PublisherFactory::createFromDb($id);
    // The choice group objects
    } else {
        $category = $_GET['category'] ?? '';
        $newsViewer = new PublicationsViewer($category);
        $publications = $newsViewer->getPublications();
    }
?>
