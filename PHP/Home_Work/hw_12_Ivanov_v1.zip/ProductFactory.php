<?php
/**
 * Created by PhpStorm.
 * User: lenovo
 * Date: 03.03.2019
 * Time: 14:02
 */

class ProductFactory
{
    public static function createProduct($id, $title, $description, $price)
    {
        $product = new Product(
            $id,
            $title,
            $description,
            $price
        );
        return $product;
    }
    public static function createFromDb($id)
    {
        $sql = 'select * from products where id=:id';
         $db = Application::connectionDB();
        $query = $db->prepare($sql);
        $query->bindValue(':id', $id);
        $query->execute();
        $data = $query->fetchObject();
        self::createProduct(
            $data->id,
            $data->title,
            $data->description,
            $data->price
        );
        var_dump($data);

    }
}