<?php

function show($message)
{
    // if open this file through console interface then...
    if (isset($_SERVER['argc']) && $_SERVER['argc'] > 0) {
        echo "\t" . $message . "\n";
    // if open this file through internet browser then...
    } else {
        echo('<p class="alert alert-info text-sm text-center col-4 mx-auto px-1 py-0 mb-1">');
        echo($message);
        echo('</p>');
    }
}