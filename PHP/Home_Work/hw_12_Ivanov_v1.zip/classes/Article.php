<?php
class Article extends Publication
{
    /**
     * Article constructor.
     * @param $author
     */
    public $superProperty;
    public function __construct($id, $title, $description, $text, $type, $author)
    {
        $this->superProperty = $author;
        parent::__construct($id, $title, $description, $text, $type, $author);
    }

}