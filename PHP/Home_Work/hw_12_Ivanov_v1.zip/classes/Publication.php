<?php
class Publication
{
    public $id;
    public $title;
    public $description;
    public $text;
    public $type;
    public $superProperty;

    /**
     * Publication constructor.
     * @param $id
     * @param $title header
     * @param $description short version text
     * @param $text contains full text of the publication
     * @param $type
     * @param $superProperty contains source from child News class OR author from child Article class
     */
    public function __construct($id, $title, $description, $text, $type, $superProperty = '')
    {
        $this->id = $id;
        $this->title = $title;
        $this->description = $description;
        $this->text = $text;
        $this->type = $type;
        $this->superProperty;
    }

    public function getTitle()
    {
        return $this->title;
    }

    public function getDescription()
    {
        return $this->description;
    }

    public function getText()
    {
        return $this->text;
    }

    public function getType()
    {
        return $this->type;
    }

    public function getSuperProperty()
    {
        return $this->superProperty;
    }

    public function getId()
    {
        return $this->id;
    }
}