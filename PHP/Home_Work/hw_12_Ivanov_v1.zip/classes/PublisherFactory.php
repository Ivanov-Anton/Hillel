<?php
require_once 'Publication.php';
require_once 'Application.php';
require_once 'Article.php';
require_once 'News.php';
require_once 'Message.php';

class PublisherFactory
{
    public static function createPublisher($id, $title, $descr, $text, $type, $property = '')
    {
        switch ($type) {
            case 'news':
                $publisher = new News(
                    $id,
                    $title,
                    $descr,
                    $text,
                    $type,
                    $property
                );
                return $publisher;
            case 'article':
                $publisher = new Article(
                    $id,
                    $title,
                    $descr,
                    $text,
                    $type,
                    $property
                );
                return $publisher;
        } // END SWITCH CASE
    }

    public static function createFromDb($id)
    {

        $db = Application::connectionDB();
        $sql = 'select * from `publications` where `id` = :id';
        try {
            $query = $db->prepare($sql);
            $query->bindValue(':id', $id);
            $query->execute();
        } catch(PDOException $e) {
            show('Error execute request');
        }
        /**
         * @var Publication $objFromDb
         */
        $objFromDb = $query->fetchObject();
        if (!is_object($objFromDb)) {
            show('No records with this index ' . $_GET['id'] . '.');
        } elseif (is_object($objFromDb)) {
            $publisher = self::createPublisher(
                $objFromDb->id,
                $objFromDb->title,
                $objFromDb->description,
                $objFromDb->text,
                $objFromDb->type,
                // If artile flow author but if news then source
                ($objFromDb->type == 'article') ? $objFromDb->author : $objFromDb->source
            );
            return $publisher;
        }
    }
}
