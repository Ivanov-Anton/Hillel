<?php
class News extends Publication
{
    /**
     * News constructor.
     * @param $source
     */
    public $superProperty;
    public function __construct($id, $title, $description, $text, $type, $source)
    {
        $this->superProperty = $source;
        parent::__construct($id, $title, $description, $text, $type, $source);
    }

}
