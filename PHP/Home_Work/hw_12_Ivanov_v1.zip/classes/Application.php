<?php
class Application
{
    /**
     * @var PDO $db
     */
    public static $db;

    /**
     * @return PDO
     */
    public static function connectionDB()
    {

        try {
            self::$db = new PDO(
                'mysql:host=localhost;dbname=publication',
                'publish_user',
                'qwerqwer123'
            );

            self::$db->setAttribute(
                PDO::ATTR_ERRMODE,
                PDO::ERRMODE_EXCEPTION
            );
            return self::$db;
        } catch (PDOException $e) {

            echo '<h4 class="alert alert-info">Unable to connect to database, more info: ' . $e->getMessage();
            echo '<br> try create database publication';
            echo '</h4>';
            die;
        }
        return self::$db;
    }
}