<?php
require_once 'Application.php';
require_once 'Publication.php';
require_once 'News.php';
require_once 'PublisherFactory.php';
require_once 'Article.php';

class PublicationsViewer
{
    /**
     * @var Publication[] $publications
     */
    public $publications;
    /**
     * PublicationsViewer constructor.
     */
    public function __construct($publictionType)
    {

        $db = Application::connectionDB();
        // we preddes the button News <<<-----------------------
        if ($publictionType == 'news') {
            $sql = 'select * from publications where type = :type';
            try {
                $query = $db->prepare($sql);
                $query->bindValue(':type', $publictionType);
                $query->execute();
            } catch(PDOException $e) {
                show('Error in category news');
            }
            /**
             * @var News $data
             */
            $dataList = $query->fetchAll(PDO::FETCH_OBJ);
            foreach ($dataList as $data){
                $this->publications[] = PublisherFactory::createPublisher(
                    $data->id,
                    $data->title,
                    $data->description,
                    $data->text,
                    $data->type,
                    $data->source
                );
            }
        // we pressed the button Article <<<---------------------
        } elseif ($publictionType == 'article') {
            $sql = 'select * from publications where type=:type';
            try {
                $query = $db->prepare($sql);
                $query->bindValue(':type', $publictionType);
                $check = $query->execute();
            } catch(PDOException $e) {
                show('Error in category article');            
            }

            /**
             * @var Article $data
             */
            $dataList = $query->fetchAll(PDO::FETCH_OBJ);

            foreach ($dataList as $data){
                $this->publications[] = PublisherFactory::createPublisher(
                    $data->id,
                    $data->title,
                    $data->description,
                    $data->text,
                    $data->type,
                    $data->author
                );
            }
        // defauld view all publication
        } else {
            $sql = 'select * from publications';
            try {
                $query = $db->query($sql);
                $query = $query->fetchAll(PDO::FETCH_OBJ);
                /**
                 * @var Publication $data
                 */
                foreach ($query as $data){
                    $this->publications[] = PublisherFactory::createPublisher(
                        $data->id,
                        $data->title,
                        $data->description,
                        $data->text,
                        $data->type,
                        ($data->type == 'article') ? $data->author : $data->source
                    );
                }
            } catch(PDOException $e) {
                show('Error in select all publications');
            }
        }
    }

    /**
     * @return Publication[]
     */
    public function getPublications()
    {
        return $this->publications;
    }
}
