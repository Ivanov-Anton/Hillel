<header>
	<nav class="navbar navbar-dark bg-dark navbar-expand">
		<a class="navbar-brand col-md-2" href="index.php">
			Hillel.com.UA
		</a>
		<div class="collapse navbar-collapse">
			<ul class="navbar-nav">
				<li class="nav-item"><a class="nav-link" href="index.php">Главная</a></li>					
				<li class="nav-item"><a class="nav-link" href="tovars.php">Товары</a></li>
			</ul>
		</div>
	</nav>
</header><!-- end navbar  -->