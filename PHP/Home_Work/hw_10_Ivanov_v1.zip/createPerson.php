<?php 
require_once('Student.php');
require_once('Coach.php');
$personList = [
	[
		'name' => 'Василий',
		'email' => 'vasyaTutcin@gmail.com',
		'phone' => '+38074521414',
		'role' => 'student',
		'rating' => '120'
	],
	[
		'name' => 'Виталий',
		'email' => 'vitaJust@gmail.com',
		'phone' => '+380936985539',
		'role' => 'student',
		'rating' => '90'
	],
	[
		'name' => 'Владимер',
		'email' => 'voloday@gmail.com',
		'phone' => '+380742345454',
		'role' => 'coach',
		'course' => 'PHP'
	],
	[
		'name' => 'Виктор',
		'email' => 'viktorV8@gmail.com',
		'phone' => '+380743456111',
		'role' => 'student',
		'rating' => '45'
	],
	[
		'name' => 'Валентина',
		'email' => 'valichke@gmail.com',
		'phone' => '+380557415587',
		'role' => 'coach',
		'course' => 'JS'
	],
	[
		'name' => 'Виктория',
		'email' => 'viktoryaV8@gmail.com',
		'phone' => '+380965583741',
		'role' => 'student',
		'rating' => '111'
	],
	[
		'name' => 'Василиса',
		'email' => 'vasilyssa123@gmail.com',
		'phone' => '+30965236565',
		'role' => 'student',
		'rating' => '88'
	],
	[
		'name' => 'Вероника',
		'email' => 'verona777@gmail.com',
		'phone' => '+30745214532',
		'role' => 'student',
		'rating' => '90'
	],
	[
		'name' => 'Вениамин',
		'email' => 'venya@gmail.com',
		'phone' => '+0989867988',
		'role' => 'student',
		'rating' => '98'
	],
	[
		'name' => 'Владиислав',
		'email' => 'vladislav007@gmail.com',
		'phone' => '+380743456111',
		'role' => 'student',
		'rating' => '101'
	],
];