<?php

/* 
 * This is file manage some pages of the web aplication
 * index.php main file 
 */
define('AGE_LIMIT', 18);
$textMessage = 'Извините вы слишком молоды';

$getUserName = empty($_POST['userName']) ? 'Имя не указано' : htmlspecialchars($_POST['userName']);    
$getAgeName = empty($_POST['ageName']) ? 0 : htmlspecialchars($_POST['ageName']);
$getStatusName = empty($_POST['statusName']) ? '' : htmlspecialchars($_POST['statusName']);
$getCommentName = empty($_POST['commentName']) ? 'Без коментария' : htmlspecialchars($_POST['commentName']);
// $_POST for don't repeat function header
if ($_POST && $getAgeName != 0 && $getAgeName < AGE_LIMIT) {
	header('Location: pageInfo.php');
} elseif ($getAgeName >= AGE_LIMIT) {
	header('Location: personalUserPage.php?'.
			'userName=' . $getUserName . 
			'&statusName=' . $getStatusName . 
			'&ageName=' . $getAgeName .
			'&commentName=' . $getCommentName
	);
// don't enter age in form then Location login.php	
} elseif ($_POST && $getAgeName == 0) {	
	header('Location: login.php');
}