<head>
	<title><?= $titlePageName ?></title>
	<meta charset="utf-8">
	<meta name="description" content="<?= $descrPage ?>">
	<link rel="stylesheet" type="text/css" href="style/style.css">
	<meta name="keywords" content="компьютерная академия, школа it, технологии, специалистов, учебный центр, Киев, Hillel"/>
	<link rel="stylesheet" type="text/css" href="style/bootstrap.css">
</head>