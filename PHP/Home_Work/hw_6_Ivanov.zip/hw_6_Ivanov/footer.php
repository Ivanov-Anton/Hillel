<div class="footer navbar navbar-dark bg-dark navbar-expand col-md-12">
	<a class="navbar-brand col-md-2" href="index.php">
		HillelUniversity.UA
	</a>
	
	<div class="collapse navbar-collapse" >
		<div class="navbar-nav col-md-12">
			<h6 class="col-md-12"><a class="nav-item nav-link text-right" href="#">HillelUniversity © 2018.</a></h6>
		</div>
	</div>
</div> <!-- FOOTER end -->