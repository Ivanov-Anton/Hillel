<?php 
    require_once('class/DB.php');
    $db = DB::getConnect();
    $sql = 'DROP table members';
    try {
        $db->exec($sql);
        DB::mssg('Drop table success!!!');
    } catch (PDOException $e) {
        DB::mssg('DROP table MEMBERS error');
    }