<header>
	<nav class="navbar navbar-dark bg-dark navbar-expand">
		<a class="navbar-brand col-md-2" href="/index.php">
			<?= $logo ?>	
		</a>
		<div class="collapse navbar-collapse">
			<ul class="navbar-nav pl-2">
				<!--Using the path relative to the Document root -->
				<li class="nav-item"><a class="nav-link" href="/index.php">Главная</a></li>	
				<li class="nav-item"><a class="nav-link" href="/pages/tovars.php">Акксесуары для телефонов</a></li>
				<li class="nav-item"><a class="nav-link disabled" href="/login.php">Компьюютеры</a></li>
				<li class="nav-item"><a class="nav-link disabled" href="/login.php">SSD</a></li>
				<li class="nav-item"><a class="nav-link disabled" href="/login.php">Ноутбуки</a></li>
				<li class="nav-item"><a class="nav-link disabled" href="/login.php">Видео карты</a></li>
				<li class="nav-item"><a class="nav-link disabled		" href="/login.php">Оперативки</a></li>
			</ul>
		</div>
	</nav>
</header><!-- end navbar  -->