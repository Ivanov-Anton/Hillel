<header>
	<nav class="navbar navbar-dark bg-dark navbar-expand">
		<a class="navbar-brand col-md-2" href="/index.php">
			Hillel.com.UA
		</a>
		<div class="collapse navbar-collapse">
			<ul class="navbar-nav">
				<!--Using the path relative to the Document root -->
				<li class="nav-item"><a class="nav-link" href="/index.php">Главная</a></li>
				<li class="nav-item"><a class="nav-link" href="/pages/students.php">Студенты</a></li>
				<li class="nav-item"><a class="nav-link" href="/pages/teachers.php">Преподователи</a></li>
				<li class="nav-item"><a class="nav-link" href="/pages/admins.php">Администраторы</a></li>
			</ul>
		</div>
	</nav>
</header><!-- end navbar  -->