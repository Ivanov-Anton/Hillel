<?php
	$users = [
		[
			'name' => 'John Doe',
			'group' => 'student',
			'email' => 'john@gmail.com',
			'phone' => '123-23-12',
		],
		[
			'name' => 'Anna Dellak',
			'group' => 'student',
			'email' => 'anna_delak@icloud.com',
			'phone' => '978-52-41',
		],
		[
			'name' => 'Bred Glory',
			'group' => 'student',
			'email' => 'Bred123Glory@yahhu.com',
			'phone' => '145-00-01',
		],
		[	'name' => 'Max Miller',
			'group' => 'student',
			'email' => 'Miller0001_1000@gmail.com',
			'phone' => '699-52-25',
		],
		[
			'name' => 'Ivan Petrov',
			'group' => 'student',
			'email' => 'Vanchel001@yandex.ru',
			'phone' => '001-88-00',
		],
		[
			'name' => 'Dmitriy Evchev',
			'group' => 'student',
			'email' => 'Evchev-Lada@rembler.ru',
			'phone' => '741-11-00',
		],
		[
			'name' => 'Denny Darckness',
			'group' => 'teacher',
			'email' => 'Dark009@gmail.com',
			'phone' => '789-47-74',
		],
		[
			'name' => 'Lao He',
			'group' => 'student',
			'email' => 'Lao1985@WangYi.cn',
			'phone' => '114-77-77',
		],
		[
			'name' => 'Aloton Jes',
			'group' => 'teacher',
			'email' => 'Alot-best123@gmail.com',
			'phone' => '741-99-99',
		],
		[
			'name' => 'Mishel Millar',
			'group' => 'admin',
			'email' => 'Mishel-123-up@gmail.com',
			'phone' => '474-88-88',
		],
	];