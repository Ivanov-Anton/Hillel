<?php

	session_start();

	session_destroy();

	// header('Location: /lesson8/site');
	header('Location: index.php');