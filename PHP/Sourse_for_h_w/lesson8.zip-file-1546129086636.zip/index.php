<?php

	session_start();

	$_SESSION['student'] = [
		'name' => 'John',
		'course' => 'PHP',
	];

