<?php

	$a = 1;
	$b = 2;
	$c = 5;

	// if (($c == 5 || $b == 1) && $a == 2) {
	// 	echo 'success';
	// }

	// round()

	$a = 14.45 / 3.45;

	// echo round($a, 2);

	define('USD', 27.45);

	// echo round(1500 / CURRENCY_USD, 2);

	$money = ['USD' => 'USD'];

	// echo $money['USD'];	

	// USD = 45; // wrong!

	const EUR = 32.76;

	echo EUR;

	
