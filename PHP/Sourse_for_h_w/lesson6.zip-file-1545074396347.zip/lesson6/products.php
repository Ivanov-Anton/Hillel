<?php

	$products = [
		[
			'title' => 'Macbook',
			'price' => 1500,
			'category' => 'Notebook',
		],
		[
			'title' => 'Thinkpad',
			'price' => 900,
			'category' => 'Notebook',
		],
		[
			'title' => 'Samsung Galaxy',
			'price' => 900,
			'category' => 'Mobile',
		],
		[
			'title' => 'iPhone',
			'price' => 1200,
			'category' => 'Mobile',
		],
		[
			'title' => 'iWatch',
			'price' => 300,
			'category' => 'Smartwatch',
		],
		[
			'title' => 'iPad',
			'price' => 400,
			'category' => 'Tablet',
		],
	];
