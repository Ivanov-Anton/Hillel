<?php

	echo 'Hello world';

	echo "\n\n";

	// Lesson 3

	/*

	here
	is
	another comment

	*/

	# Old style comment

	// $a $b $c // bad naming

	// $some_good_variable

	$firstName = 'John';

	$age = 38;

	// echo '<br>';

	echo $age;

	$a = 8;
	$b = $a;

	echo $b;

	echo "Hello \\\\ \"$firstName\"\n";
	echo "Age : \"$age\"\n\n";

	echo 'Price \' "$a"';
	echo "\n\n";

	///

	$a = "Lesson";
	$b = 3;
	$c = $a + $b;

	echo $c;

	echo "\n\n"; // "<br>";

	$a = 34;
	$b = 45;
	$c = $a + $b;

	$str = $a . ' + ' . $b . ' = ' . $c;

	echo $str;

	// $123h1ello <--- incorrect

	echo "\n\n\n";
