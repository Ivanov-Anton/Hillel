<?php

	$students = [
		'John',
		'Stan',
		'Julia',
		'Bob',
	];

	// $numbers = array(1, 9, 56); <-- do not do this

	echo 'Name : ' . $students[2] ; // Array

	print_r($students);

	$students[2] = 'Anna';

	print_r($students);

	// var_dump($students);



	echo "\n\n\n";

