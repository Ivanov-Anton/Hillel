<?php

define('ADMIN_EMAIL', 'asdf@asdf.com');

class Settings
{
	public const MODE = 'develop';

	// self::MODE
	// static::MODE
	
}

echo Settings::MODE;

